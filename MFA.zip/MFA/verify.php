<?php
session_start();

// Check if MFA is required
if (!isset($_SESSION['mfa_required']) || !$_SESSION['mfa_required']) {
    header("Location: login.php");
    exit;
}

$email = $_SESSION['email']; // Get the user's email from the session

// Include PHPMailer library
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Require PHPMailer library files
require 'vendor/autoload.php';

// Generate and send the verification code if not already done
if (!isset($_SESSION['verification_code'])) {
    $verification_code = rand(100000, 999999); // Generate a 6-digit code
    $_SESSION['verification_code'] = $verification_code;

    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';                       // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = 'sfomutere@gmail.com';             // SMTP username
        $mail->Password = 'pauv wxkv pgvi kqce';              // SMTP password
        $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 587;                                    // TCP port to connect to

        //Recipients
        $mail->setFrom('no-reply@yourdomain.com', 'USIU-MFA Project');
        $mail->addAddress($email);                            // Add a recipient

        // Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Your Verification Code';
        $mail->Body    = 'Your verification code is: <b>' . $verification_code . '</b>';
        $mail->AltBody = 'Your verification code is: ' . $verification_code;

        $mail->send();
        echo 'Verification code has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_code = $_POST['verification_code'];

    // Check if the entered code matches the sent code
    if ($entered_code == $_SESSION['verification_code']) {
        // Code is correct, complete the login
        $_SESSION['user_id'] = $_SESSION['temp_user_id'];
        $_SESSION['first_name'] = $_SESSION['temp_first_name'];
        unset($_SESSION['mfa_required']);
        unset($_SESSION['verification_code']);
        unset($_SESSION['temp_user_id']);
        unset($_SESSION['temp_first_name']);
        header("Location: index.php");
        exit;
    } else {
        $error_message = "Invalid verification code.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verification</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .verification-container {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        .verification-header {
            font-size: 1.5rem;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }
        .form-control:focus {
            box-shadow: none;
            border-color: #007bff;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .error-message {
            color: #dc3545;
            margin-top: 10px;
            text-align: center;
			 /* Card styling for the hint */
        .hint-card {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #fff3cd;
            border: 1px solid #ffeeba;
            border-radius: 5px;
            color: #856404;
            margin-bottom: 15px;
            font-size: 14px;
        }

        /* Exclamation mark styling */
        .hint-card .exclamation {
            font-weight: bold;
            font-size: 18px;
            margin-right: 8px;
            color: #856404;
        }

        /* Button styling */
        .email-button {
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="verification-container">
        <div class="verification-header">Verification</div>
        <form method="post" action="verify.php">
            <div class="form-group">
                <label for="verification_code">Enter Verification Code</label>
                <input type="text" class="form-control" id="verification_code" name="verification_code" required>
            </div>
            <?php if (isset($error_message)): ?>
                <div class="error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <button type="submit" class="btn btn-primary btn-block">Verify</button>
			<div class="hint-card">
             <span class="exclamation">❗</span>
               Are you having trouble with verification? 
            </div>
			<a href="mailto:cyrusesservices@gmail.com" class="email-button">Contact Admin</a>
        </form>
    </div>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
