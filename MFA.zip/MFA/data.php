<?php
require 'db_connection.php';

// Fetch metrics
$metricsStmt = $pdo->query("SELECT metric_name, metric_value, recorded_at FROM metrics ORDER BY recorded_at DESC LIMIT 10");
$metrics = $metricsStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch recent logins
$loginsStmt = $pdo->query("SELECT u.first_name, u.last_name, l.login_time, l.ip_address, l.successful
                           FROM logins l
                           JOIN users u ON l.user_id = u.user_id
                           ORDER BY l.login_time DESC LIMIT 5");
$logins = $loginsStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch alerts
$alertsStmt = $pdo->query("SELECT a.alert_type, a.alert_message, a.created_at, u.first_name, u.last_name
                           FROM alerts a
                           LEFT JOIN users u ON a.user_id = u.user_id
                           ORDER BY a.created_at DESC LIMIT 5");
$alerts = $alertsStmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'metrics' => $metrics,
    'logins' => $logins,
    'alerts' => $alerts
]);
?>
