<?php
require 'db.php';

$email = 'admin@example.com';
$password = 'admin123';

// Hash the password
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Insert admin into database
$stmt = $pdo->prepare("INSERT INTO admin (email, password) VALUES (?, ?)");
$stmt->execute([$email, $hashed_password]);

echo "Admin user created successfully!";
?>
