<?php
session_start();
require 'db.php';

// Ensure the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// Fetch user information
if (isset($_GET['user_id'])) {
    $userId = intval($_GET['user_id']);
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Fetch user's login attempts
$stmt = $conn->prepare("SELECT * FROM login_attempts WHERE user_id = ? ORDER BY attempt_time DESC");
$stmt->bind_param('i', $userId);
$stmt->execute();
$loginAttempts = $stmt->get_result();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View User</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <h2>User Details</h2>
    <?php if ($user): ?>
        <table class="table table-bordered">
            <tr>
                <th>First Name</th>
                <td><?= htmlspecialchars($user['first_name']) ?></td>
            </tr>
            <tr>
                <th>Last Name</th>
                <td><?= htmlspecialchars($user['last_name']) ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?= htmlspecialchars($user['email']) ?></td>
            </tr>
            <tr>
                <th>Phone Number</th>
                <td><?= htmlspecialchars($user['phone_number']) ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td><?= $user['blocked'] ? 'Blocked' : 'Active' ?></td>
            </tr>
        </table>

        <h3>Login Attempts</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Attempt Time</th>
                    <th>Success</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($attempt = $loginAttempts->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($attempt['attempt_time']) ?></td>
                        <td><?= $attempt['success'] ? 'Yes' : 'No' ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <a href="index.php" class="btn btn-primary">Back to Dashboard</a>
    <?php else: ?>
        <p class="text-danger">User not found!</p>
    <?php endif; ?>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
