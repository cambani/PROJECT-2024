
<?php
$servername = "localhost"; // Typically "localhost" if running on your local server
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "mfa"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Create a new PDO instance using the original variable names
$dsn = "mysql:host=$servername;dbname=$dbname;charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, // Enable exceptions for error handling
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // Fetch results as associative arrays
    PDO::ATTR_EMULATE_PREPARES => false, // Disable emulated prepares for increased security
];

try {
    $pdo = new PDO($dsn, $username, $password, $options);
} catch (\PDOException $e) {
    // Handle connection errors gracefully
    echo "Database connection failed: " . $e->getMessage();
    exit;
}
?>
