<?php
session_start();
require 'db.php';

// Ensure the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// Fetch users and their login attempts
$query = "
    SELECT 
        users.user_id, 
        users.first_name, 
        users.last_name, 
        users.email, 
        users.blocked,
        COUNT(login_attempts.id) as failed_attempts
    FROM 
        users
    LEFT JOIN 
        login_attempts ON users.user_id = login_attempts.user_id AND login_attempts.success = 0
    GROUP BY 
        users.user_id
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Risk Assessment Dashboard</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
        }
        .sidebar {
            height: 100vh;
            background-color: #343a40;
            color: #fff;
            padding-top: 20px;
        }
        .sidebar a {
            color: #fff;
            padding: 10px;
            display: block;
            text-decoration: none;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 d-none d-md-block sidebar">
            <div class="sidebar-sticky">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">User Management</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logs.php">Logs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="settings.php">Settings</a>
                    </li>
					<li class="nav-item">
                        <a class="nav-link" href="logout.php">logout</a>
                     </li>
                </ul>
            </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
            <h2>Risk Assessment Dashboard</h2>
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Failed Attempts</th>
                            <th>Risk Level</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) ?></td>
                                <td><?= htmlspecialchars($row['email']) ?></td>
                                <td><?= (int)$row['failed_attempts'] ?></td>
                                <td>
                                    <?php
                                    $riskLevel = 'Low';
                                    if ($row['failed_attempts'] >= 3) {
                                        $riskLevel = 'High';
                                    } elseif ($row['failed_attempts'] == 2) {
                                        $riskLevel = 'Medium';
                                    }
                                    ?>
                                    <span class="badge badge-<?php echo $riskLevel == 'High' ? 'danger' : ($riskLevel == 'Medium' ? 'warning' : 'success'); ?>">
                                        <?= $riskLevel ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="view_user.php?user_id=<?= $row['user_id'] ?>" class="btn btn-info btn-sm">View</a>
                                    <?php if ($row['blocked']): ?>
                                        <a href="block_user.php?action=unblock&user_id=<?= $row['user_id'] ?>" class="btn btn-success btn-sm">Unblock</a>
                                    <?php elseif ($row['failed_attempts'] >= 3): ?>
                                        <a href="block_user.php?action=block&user_id=<?= $row['user_id'] ?>" class="btn btn-danger btn-sm">Block</a>
                                    <?php else: ?>
                                        <button class="btn btn-secondary btn-sm" disabled>Block</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
