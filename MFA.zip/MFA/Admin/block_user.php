<?php
session_start();
require 'db.php';

// Ensure the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// Check action and user_id
if (isset($_GET['action']) && isset($_GET['user_id'])) {
    $userId = intval($_GET['user_id']);
    $action = $_GET['action'];

    if ($action == 'block') {
        $stmt = $conn->prepare("UPDATE users SET blocked = 1 WHERE user_id = ?");
    } elseif ($action == 'unblock') {
        $stmt = $conn->prepare("UPDATE users SET blocked = 0 WHERE user_id = ?");
    }

    $stmt->bind_param('i', $userId);
    if ($stmt->execute()) {
        header('Location: index.php');
    } else {
        echo "Error: " . $conn->error;
    }
    $stmt->close();
} else {
    echo "Invalid request.";
}
?>
