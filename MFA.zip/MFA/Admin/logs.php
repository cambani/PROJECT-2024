<?php
session_start();
require 'db.php'; // Ensure the database connection is available

// Ensure the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// Function to classify risk level based on failed login attempts
function classifyRiskLevel($failedAttempts) {
    if ($failedAttempts >= 3) {
        return 'High';
    } elseif ($failedAttempts === 2) {
        return 'Medium';
    } else {
        return 'Low';
    }
}

// Fetch users and their login attempts
$query = "
    SELECT 
        users.user_id, 
        users.first_name, 
        users.last_name, 
        users.email, 
        users.blocked,
        COUNT(login_attempts.id) as failed_attempts
    FROM 
        users
    LEFT JOIN 
        login_attempts ON users.user_id = login_attempts.user_id AND login_attempts.success = 0
    GROUP BY 
        users.user_id
    ORDER BY
        failed_attempts DESC, users.user_id ASC
";

$stmt = $pdo->query($query);
$users = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - User Login Logs</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 50px;
        }
        .container {
            max-width: 900px;
            margin: auto;
        }
        table {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        th {
            background-color: #007bff;
            color: #ffffff;
            text-align: center;
        }
        .btn-view, .btn-unblock {
            margin: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">User Login Attempts Log</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Failed Attempts</th>
                    <th>Risk Level</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['user_id']); ?></td>
                        <td><?= htmlspecialchars($user['first_name']); ?></td>
                        <td><?= htmlspecialchars($user['last_name']); ?></td>
                        <td><?= htmlspecialchars($user['email']); ?></td>
                        <td class="text-center"><?= $user['failed_attempts']; ?></td>
                        <td class="text-center">
                            <?php 
                            $riskLevel = classifyRiskLevel($user['failed_attempts']);
                            $riskClass = ($riskLevel === 'High') ? 'text-danger' : (($riskLevel === 'Medium') ? 'text-warning' : 'text-success');
                            ?>
                            <span class="<?= $riskClass; ?>"><?= $riskLevel; ?></span>
                        </td>
                        <td class="text-center"><?= $user['blocked'] ? 'Blocked' : 'Active'; ?></td>
                        <td class="text-center">
                            <a href="view_user.php?id=<?= $user['user_id']; ?>" class="btn btn-info btn-sm btn-view">View</a>
                            <?php if ($user['blocked']): ?>
                                <a href="unblock_user.php?id=<?= $user['user_id']; ?>" class="btn btn-success btn-sm btn-unblock">Unblock</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
