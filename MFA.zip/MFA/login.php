<?php
session_start(); // Start the session to manage user authentication

// Database connection parameters
require_once 'db_connection.php';

// Handle form submission
$error_message = ''; // Initialize an empty error message
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Retrieve user data from the database
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        if ($user['blocked']) {
            // User is blocked
            $error_message = "Your account is blocked due to multiple failed login attempts. Please contact support.";
        } elseif (password_verify($password, $user['password'])) {
            // Successful login
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['first_name'] = $user['first_name'];

            // Clear failed login attempts on successful login
            $clearAttemptsSql = "DELETE FROM login_attempts WHERE user_id = ?";
            $clearStmt = $pdo->prepare($clearAttemptsSql);
            $clearStmt->execute([$user['user_id']]);

            // Redirect based on MFA requirement
            if (isset($_SESSION['failed_login']) && $_SESSION['failed_login'] >= 1) {
                // Reset failed login attempts
                unset($_SESSION['failed_login']);
                // Require MFA verification
                $_SESSION['mfa_required'] = true;
                $_SESSION['email'] = $email;
                header("Location: verify.php");
                exit;
            } else {
                // Successful login without MFA requirement
                header("Location: index.php");
                exit;
            }
        } else {
            // Invalid password
            $error_message = "Invalid email or password.";

            // Log the failed attempt
            $logAttemptSql = "INSERT INTO login_attempts (user_id, success) VALUES (?, 0)";
            $logStmt = $pdo->prepare($logAttemptSql);
            $logStmt->execute([$user['user_id']]);

            // Check the number of consecutive failed login attempts
            $failedAttemptsSql = "SELECT COUNT(*) as failed_attempts 
                                  FROM login_attempts 
                                  WHERE user_id = ? AND success = 0 AND attempt_time > (NOW() - INTERVAL 15 MINUTE)";
            $failedStmt = $pdo->prepare($failedAttemptsSql);
            $failedStmt->execute([$user['user_id']]);
            $failedAttempts = $failedStmt->fetchColumn();

            if ($failedAttempts >= 3) {
                // Block the user
                $blockUserSql = "UPDATE users SET blocked = 1 WHERE user_id = ?";
                $blockStmt = $pdo->prepare($blockUserSql);
                $blockStmt->execute([$user['user_id']]);

                $error_message = "Your account has been blocked due to multiple failed login attempts.";
            }

            if (!isset($_SESSION['failed_login'])) {
                $_SESSION['failed_login'] = 1;
            } else {
                $_SESSION['failed_login']++;
            }
        }
    } else {
        // Invalid email
        $error_message = "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        .login-header {
            font-size: 1.5rem;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }
        .form-control:focus {
            box-shadow: none;
            border-color: #007bff;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .register-link {
            display: block;
            text-align: center;
            margin-top: 10px;
        }
        .error-message {
            color: #dc3545;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">Login</div>
        <form method="post" action="login.php">
            <div class="form-group">
                <label for="email">Email address</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <?php if ($error_message): ?>
                <div class="error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <button type="submit" class="btn btn-primary btn-block">Login</button>
            <a href="register.php" class="register-link">New user? Register here</a>
        </form>
    </div>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
