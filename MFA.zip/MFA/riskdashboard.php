<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Risk Assessment Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            padding-top: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 1200px;
            margin: auto;
        }
        .card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <!-- Metrics Graph -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Metrics Overview</div>
                    <div class="card-body">
                        <canvas id="metricsChart"></canvas>
                    </div>
                </div>
            </div>
            <!-- Recent Logins -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Recent Logins</div>
                    <div class="card-body">
                        <ul class="list-group" id="loginsList">
                            <!-- Recent logins will be populated here -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Alerts -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Alerts</div>
                    <div class="card-body">
                        <ul class="list-group" id="alertsList">
                            <!-- Alerts will be populated here -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer -->
        <footer class="footer mt-auto py-3">
            <div class="container text-center">
                <span class="text-muted">Risk Dashboard © 2024</span>
            </div>
        </footer>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Fetch data from the server
            $.getJSON('data.php', function(data) {
                // Populate metrics chart
                const metricsLabels = data.metrics.map(metric => metric.metric_name);
                const metricsValues = data.metrics.map(metric => metric.metric_value);
                
                const metricsChartCtx = document.getElementById('metricsChart').getContext('2d');
                new Chart(metricsChartCtx, {
                    type: 'line',
                    data: {
                        labels: metricsLabels,
                        datasets: [{
                            label: 'Metric Value',
                            data: metricsValues,
                            borderColor: 'rgba(75, 192, 192, 1)',
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            fill: true
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });

                // Populate recent logins list
                data.logins.forEach(login => {
                    $('#loginsList').append(
                        `<li class="list-group-item">
                            ${login.first_name} ${login.last_name} - ${login.login_time} (${login.ip_address}) 
                            <span class="badge badge-${login.successful ? 'success' : 'danger'} float-right">${login.successful ? 'Success' : 'Failed'}</span>
                        </li>`
                    );
                });

                // Populate alerts list
                data.alerts.forEach(alert => {
                    $('#alertsList').append(
                        `<li class="list-group-item">
                            ${alert.first_name ? alert.first_name + ' ' + alert.last_name : 'System'}: 
                            ${alert.alert_message} 
                            <span class="badge badge-warning float-right">${alert.alert_type}</span>
                        </li>`
                    );
                });
            });
        });
    </script>
</body>
</html>
